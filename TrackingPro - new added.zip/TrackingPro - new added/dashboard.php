<?php 
	include 'lib/header.php'; 
	
	if($_SESSION['login_user']){
		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => "https://login.trakingpro.com/api/get_devices?lang=en&user_api_hash=$_SESSION[login_user]",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencoded","Cookie:laravel_session=eyJpdiI6IlhkVUxDSmVqdFhza2FQSmNCOTBtRFE9PSIsInZhbHVlIjoiUlhiYjBDVjNxZEpIY3VFMjZBTlhONndicWJoUnBiRytXODVxOHVJY0hDajdURlNYYUx3YjA1R05iMXNGTVVyTTFmY3kxUzhIdVh2Y1U2NHVHS1pBM3lBcGdlNHBDN3pMbFlaRzBFQmh3V3Z5QUVLTXl4VnJ5eklNMWJKVE5XMTgiLCJtYWMiOiJlZmUwZGY3MGVmMmJkODRlMmYzM2ZmMjU2ZGVmNmE4MDExN2E2YTEyMjNiYjVhYzNlYWIwMmJmNGYwYTE5MTMzIn0%3D"
		),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		$data=json_decode($response,true);
		$device=count($data[0]['items']);
	?>
	<main class="dash-container">
		<div class="row">
			<div class="col-md-2 dash-card2">
				<div class="tr-card tr-primary">
					<span class="wid-title"><?=$device;?></span>
					<span class="wid-desc">Total Device</span>
					<span class="corner-1"></span>
				</div>
			</div>
			<div class="col-md-2 dash-card2">
				<div class="tr-card tr-green">
					<span class="wid-title">0</span>
					<span class="wid-desc">Total Device</span>
				</div>
			</div>
			<div class="col-md-2 dash-card2">
				<div class="tr-card tr-yellow">
					<span class="wid-title">0</span>
					<span class="wid-desc">Total Device</span>
				</div>
			</div>
			<div class="col-md-2 dash-card2">
				<div class="tr-card tr-red">
					<span class="wid-title">0</span>
					<span class="wid-desc">Total Device</span>
				</div>
			</div>
			<div class="col-md-2 dash-card2">
				<div class="tr-card tr-violet">
					<span class="wid-title">0</span>
					<span class="wid-desc">Total Device</span>
				</div>
			</div>
			<div class="col-md-2 dash-card2">
				<div class="tr-card tr-grey">
					<span class="wid-title">0</span>
					<span class="wid-desc">Total Device</span>
				</div>
			</div>
		</div>

			<div class="row">
			<div class="col-md-4 dash-card">
			<h1 class="fuel-title">Fuel Price</h1>
			<select name="" id="" class="trf-select mt-2">
			<option value="">Select State</option>
			</select>

			<div class="row mt-3">
			<div class="col-md-6 dash-card">
			<div class="price-title tr-ydark">petrol</div>
			<div class="oil-price tr-yellow"> ₹77.97/litre</div>
			</div>

			<div class="col-md-6 dash-card">
			<div class="price-title tr-gdark">disel</div>
			<div class="oil-price tr-green"> ₹77.97/litre</div>
			</div>
			</div>
			</div>

			<div class="col-md-4 dash-card">
			<div class="card">
			<canvas id="myChart" width="400" height="200"></canvas>

			<script>
			var ctx = document.getElementById('myChart').getContext('2d');
			var myChart = new Chart(ctx, {
			type: 'pie',
			data: {
			labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
			datasets: [{
			label: '# of Votes',
			data: [12, 19, 3, 5, 2, 3],
			backgroundColor: [
			'rgba(255, 99, 132, 0.2)',
			'rgba(54, 162, 235, 0.2)',
			'rgba(255, 206, 86, 0.2)',
			'rgba(75, 192, 192, 0.2)',
			'rgba(153, 102, 255, 0.2)',
			'rgba(255, 159, 64, 0.2)'
			],
			borderColor: [
			'rgba(255, 99, 132, 1)',
			'rgba(54, 162, 235, 1)',
			'rgba(255, 206, 86, 1)',
			'rgba(75, 192, 192, 1)',
			'rgba(153, 102, 255, 1)',
			'rgba(255, 159, 64, 1)'
			],
			borderWidth: 1
			}]
			},
			options: {
			scales: {
			yAxes: [{
			ticks: {
			beginAtZero: true
			}
			}]
			}
			}
			});
			</script>
			</div>
			</div>

			<div class="col-md-4 dash-card">
			<div class="card">
			<canvas id="myChart2" width="400" height="200"></canvas>
			<script>
			var ctx = document.getElementById('myChart2').getContext('2d');
			var myChart = new Chart(ctx, {
			type: 'pie',
			data: {
			labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
			datasets: [{
			label: '# of Votes',
			data: [12, 19, 3, 5, 2, 3],
			backgroundColor: [
			'rgba(255, 99, 132, 0.2)',
			'rgba(54, 162, 235, 0.2)',
			'rgba(255, 206, 86, 0.2)',
			'rgba(75, 192, 192, 0.2)',
			'rgba(153, 102, 255, 0.2)',
			'rgba(255, 159, 64, 0.2)'
			],
			borderColor: [
			'rgba(255, 99, 132, 1)',
			'rgba(54, 162, 235, 1)',
			'rgba(255, 206, 86, 1)',
			'rgba(75, 192, 192, 1)',
			'rgba(153, 102, 255, 1)',
			'rgba(255, 159, 64, 1)'
			],
			borderWidth: 1
			}]
			},
			options: {
			scales: {
			yAxes: [{
			ticks: {
			beginAtZero: true
			}
			}]
			}
			}
			});
			</script>
			</div>

			</div>
			</div>

			<div class="card mt-1 mb-5 dash-table panel panel-default" style="overflow-x:auto;">
			<table class="table table-rounded">
			<thead class="table-title">
			<tr>
			<th scope="col">Icon</th>
			<th scope="col">Reg.No.</th>
			<th scope="col">GPS</th>
			<th scope="col">Last Location</th>
			<th scope="col">Last Update</th>
			<th scope="col">Status</th>
			<th scope="col">Speed</th>
			<th scope="col">Map</th>
			<!--<th scope="col">Power</th>-->
			<th scope="col">IGN</th>
			</tr>
			</thead>

			<tbody>
				
			<?php 
			$x = 0;

			while($x < $device){
				
			$y=$x++;
			$id=$data[0]['items'][$y]['id'];

			///////-----------------------------map--------------------------------------
			$lat=$data[0]['items'][0]['lat'];
			$lng=$data[0]['items'][0]['lng'];

			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://revgeocode.search.hereapi.com/v1/revgeocode?at=$lat,$lng&lang=en-US&apiKey=IUgw7SSNauPfFQLLU1pbu5WkBaKFMCv_qidSXlqbEG0",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));
			$response = curl_exec($curl);
			curl_close($curl);
			$someArray = json_decode($response, true);
			$add=$someArray['items'][0]['title'];
			?>    
			<tr>
			<!--<th><i class="material-icons">local_shipping</i></th>-->

			<th><a href="map.php?id=<?php echo $id;?>&is_history=0"><i class="material-icons">local_shipping</i></a></th>

			<td style = "white-space:nowrap"><span class="tr-plate"><a href="map.php?id=<?php echo $id;?>&is_history=0"><?=$data[0]['items'][$y++]['name'];?></a></span></td>

			<?php $sts=$data[0]['items'][0]['online'];

			if($sts='ack'){
			?>
			<td><i class="material-icons text-success"> my_location</i></td>
			<?php } else { ?>

			<td><i class="material-icons">my_location</i></td>

			<?php } ?>


			<td><?=$add;?></td>
			<td><?=$data[0]['items'][0]['time'];?></td>
			<td>STOPPED Since 0 hour, 6 minutes</td>
			<td><i class="material-icons"><?=$data[0]['items'][0]['speed'];?></i></td>
			<td><span class="tr-plate"><a href="map.php?id=<?php echo $id;?>&is_history=0">View</a></span></td>

			<!--<td><i class="material-icons">power_settings_new</i></td>-->
			<td><i class="material-icons">flip_camera_android</i></td>
			</tr>

			<?php } ?>
			 
			 <!--https://login.trakingpro.com/images/device_icons/5e40fe2931ca60.06816032_ack.png-->

			 
			 
			</tbody>
			</table>
			</div>
			</main><!-- /.container -->
			<!-- Bootstrap core JavaScript
			================================================== -->
			<!-- Placed at the end of the document so the pages load faster -->
			<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
			<script>window.jQuery || document.write('<script src="js/jquery-slim.min.js"><\/script>')</script>
			<script src="js/popper.min.js"></script>
			<script src="js/bootstrap.min.js"></script>
			</body>
			</html>
		<?php
	}else{
		header('location:index.php');
	}
?>