<?php
	include_once('config.php');
	$sql = "INSERT INTO `token`(`token`) VALUES ('".$_POST['token']."')";
	$res = mysqli_query($conn, $sql);
?>