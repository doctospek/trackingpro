<?php
  // include('session.php');
  
  session_start();

$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://revgeocode.search.hereapi.com/v1/revgeocode?at=23.082764,86.248418&lang=en-US&apiKey=IUgw7SSNauPfFQLLU1pbu5WkBaKFMCv_qidSXlqbEG0",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
));
$response = curl_exec($curl);
curl_close($curl);
$someArray = json_decode($response, true);

echo '<pre>';
print_r($someArray[items][0][title]);
echo '</pre>';  
?>
<html">
   
   <head>
      <title>Welcome </title>
   </head>
   
   <body>
      <h1>Welcome User ID : <?php echo $_SESSION['login_user']; ?></h1> 
      <h2><a href = "logout.php">Sign Out</a></h2>

<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://login.trakingpro.com/api/get_devices?lang=en&user_api_hash=$_SESSION[login_user]",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencoded",
    "Cookie: laravel_session=eyJpdiI6IlhkVUxDSmVqdFhza2FQSmNCOTBtRFE9PSIsInZhbHVlIjoiUlhiYjBDVjNxZEpIY3VFMjZBTlhONndicWJoUnBiRytXODVxOHVJY0hDajdURlNYYUx3YjA1R05iMXNGTVVyTTFmY3kxUzhIdVh2Y1U2NHVHS1pBM3lBcGdlNHBDN3pMbFlaRzBFQmh3V3Z5QUVLTXl4VnJ5eklNMWJKVE5XMTgiLCJtYWMiOiJlZmUwZGY3MGVmMmJkODRlMmYzM2ZmMjU2ZGVmNmE4MDExN2E2YTEyMjNiYjVhYzNlYWIwMmJmNGYwYTE5MTMzIn0%3D"
  ),
));

$response = curl_exec($curl);
curl_close($curl);
$data=json_decode($response,true);


echo "User Basic Info : </br>";
echo "ID". count($data[0][items]).'</br>';

echo  $name=$data[0][items][0][name];


echo "<pre>";
print_r($data);
echo "</pre>";
?>      
      
      
      
   </body>
   
</html>