<?php
	include_once('config.php');
	include('phpmailer/PHPMailerAutoload.php');	
	
	$sql = "SELECT * FROM `admin` WHERE `username`='".$_POST['email']."'";
	$res = mysqli_query($conn, $sql);
	
	if(mysqli_num_rows($res) > 0){
		$row = mysqli_fetch_array($res);
		$my_password = base64_decode($row['password']);
		
		$username = "dipkulkarni75@gmail.com";
		$password = "9970470160";
		
		$mail = new PHPMailer;
		$mail->Username = $username;
		$mail->Password = $password;
		$mail->CharSet = 'UTF-8';
		
		$mail->isSMTP();
		$mail->Host = 'localhost';
		$mail->SMTPAuth = false;
		$mail->SMTPAutoTLS = false; 
		$mail->Port = 25; 
		
		$mail->IsHTML(true);  
		$mail->From = $username;
		$to = $_POST['email'];
		$mail->addAddress($to);
		$mail->FromName = 'TrackingPro';
		$mail->AddReplyTo($username, 'TrackingPro');
		$mail->Subject = 'TrackingPro - Password';
		
		$mailContent = '<html><body><table width="60%" style="border-radius:4px;border:1px #dceaf5 solid" align="center" cellpadding = "5px">
				<tbody>
					<tr>
						<td width="100%" style="font-size:0px;background-color:" align="center" height="3">
							<a href="#" ><h2>Tracking Pro</h2></a>
						</td>
					</tr>
					<tr>
						<td>
							<h4>Dear User,</h4>
							<p>Your username and password for TrackingPro is : </p>
							<p>Username - '.$_POST['email'].' and <br/> Password - '.$mypassword.'</p>
							<p>To login to your Tracking Pro account  - <a href = "http://stonebank.in/new/">click here</a></p>
							<p><strong>Contact us,</strong></p>
							<p>Tracking Pro</p>
						</td> 
					</tr>
				<tbody>
			</table>
		</body></html>';
		$mail->Body = $mailContent;
	
		if(!$mail->send()){
			//echo $mail->ErrorInfo;
			header('location:forgot.php?msg=err');
		}else{
			//echo "success";
			header('location:forgot.php?msg=succ');
		}
	}else{
	    header('location:forgot.php?msg=mail');
	}
?>