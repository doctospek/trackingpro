<?php
session_start();
error_reporting(0);

if($_SERVER["REQUEST_METHOD"] == "POST") {

$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://login.trakingpro.com/api/login?email=$_POST[email]&password=$_POST[pass]",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencod"),));
$response = curl_exec($curl);
curl_close($curl);
$data=json_decode($response,true);

// echo '<pre>';
// print_r($data[user_api_hash]);
// echo '</pre>';
$id=$data[user_api_hash];

if($id == true) {
//session_register("myusername");
$_SESSION['login_user'] = $id;

header("location: dashboard.php");
}else {
$error = "Your Login Name or Password is invalid";
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="author" content="Sugata Majumder">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<script src="js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">
<title>Trakingpro User Login</title>
</head>

<body class="bg-aqua">
<div class="jumbotron ">
<div class="container">
<div class="row">
<div class="col-md-7 login-msg">
<span class="vertical-center">
Welcome to the most emerging<br>
<h1>gps tracking company</h1>
<!--<button class="btn btn-warning">Request Demo</button>-->
<!--<button class="btn btn-warning">Download</button>-->
</span>
</div>

<div class="col-md-5 login-box">
    
<form action = "forgotdata.php" method = "post">
    
<div class="text-center">
<img src="img/logo.png" class="mb-3" alt="" width="230">
</div>

<label for="inputEmail" class="visually-hidden">Email address</label>
<span class="material-icons icons">fingerprint</span>
<input type="email" id="inputEmail" class="form-control login-input" placeholder="Email address" name = "email" required >


<input type="submit" class="w-30 btn btn-lg btn-primary btn-login" value="Confirm" >



<a href="index.php" class="w-50 btn btn-lg btn-primary btn-login"  > Back To Login</a>



<div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>

</form>

<!--<div class="row app-link">-->
<!--<div class="col-md-6 col-sm-6 app-ico text-center"><img src="img/google-play.png" alt=""></div>-->
<!--<div class="col-md-6 col-sm-6 app-ico text-center"><img src="img/apple.png" alt=""></div>-->
<!--</div>-->
</div>
</div>

<div class="col-md-6 mobile-view">
<button class="btn btn-warning">Request Demo</button>
<button class="btn btn-warning">Download</button>
</div>

</div>
</div>

</body>
</html>