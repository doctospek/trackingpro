<?php 
	include 'lib/header.php'; 
	$curl = curl_init();
	curl_setopt_array($curl, array(
	CURLOPT_URL => "https://login.trakingpro.com/api/get_history?lang=en&from_date=".$_POST['from_date']."&from_time=".$_POST['from_time']."&to_date=".$_POST['to_date']."&to_time=".$_POST['to_time']."&user_api_hash=$2y$10$2MW6Gu6l3azu4hAtLam.IO0098klDrojYzXaZ7f7eojkFrY4ZPMWq&time=1461956486&device_id=".$_POST['device_id'],
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 0,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
	CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencod"),));
	$response = curl_exec($curl);
	curl_close($curl);
	$data = json_decode($response, true);
?>
<script>
	function exportF(elem) {
	  var table = document.getElementById("tableid");
	  var html = table.outerHTML;
	  var url = 'data:application/vnd.ms-excel,' + escape(html); // Set your html table into url 
	  elem.setAttribute("href", url);
	  elem.setAttribute("download", "report.xls"); // Choose the file name
	  return false;
	}
</script>
<div class = "container">
	<div class = "card">
		<div class="row"><br/><br/><br/><br/>
			<div class="col-md-12 mt-4 table-responsive">
				<?php
					error_reporting(0);
				?>
				<div class="pull-left">
					<a id="downloadLink" href="#" class="btn btn-primary text-white" onclick="exportF(this)">Download Excel</a>
					<button onclick="test()" href="#" class="btn btn-primary">Download PDF</button>
				</div>
				<div id = "tableid">
					<table class="table table-stripped" id = "datatable">
						<thead>
							<tr>
								<td width=  "50%"><img src = "img/logo_small.jpg" ></td>
								<td></td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Report type: General information</td>
								<td><?php echo $_POST['from_date'].' '.$_POST['from_time'].' To '.$_POST['to_date'].' '.$_POST['to_time']; ?></td>
							</tr>
							<tr>
								<td>Device</td>
								<td><?php echo $data['items'][0]['items'][0]['id']; ?></td>
							</tr>
							<tr>
								<td>Route Start:</td>
								<td><?php echo $data['items'][0]['items'][0]['route_start']; ?></td>
							</tr>
							<tr>
								<td>Route End:</td>
								<td><?php echo $data['items'][0]['items'][0]['route_start']; ?></td>
							</tr>
							<tr>
								<td>Route lengtd:</td>
								<td><?php echo $data['distance_sum']; ?></td>
							</tr>
							<tr>
								<td>Move Duration:</td>
								<td><?php echo $data['move_duration']; ?></td>
							</tr>
							<tr>
								<td>Stop Duration:</td>
								<td><?php echo $data['stop_duration']; ?></td>
							</tr>
							<tr>
								<td>Top speed:</td>
								<td><?php echo $data['top_speed']; ?></td>
							</tr>
							<tr>
								<td>Average speed:</td>
								<td><?php echo $data['items'][1]['average_speed']; ?></td>
							</tr>
							<tr>
								<td>Overspeed count:</td>
								<td><?php echo $data['items'][0]['items'][0]['overspeed']; ?></td>
							</tr>
							<tr>
								<td>Engine hours:</td>
								<td><?php echo $data['device']['engine_hours']; ?></td>
							</tr>
							<tr>
								<td>Engine work:</td>
								<td><?php echo $data['items'][1]['engine_work']; ?></td>
							</tr>
							<tr>
								<td>Engine idle:</td>
								<td><?php echo $data['items'][1]['engine_idle']; ?></td>
							</tr>
							<tr>
								<td>Odometer:</td>
								<td><?php echo $data['items'][0]['items'][0]['stop_duration']; ?></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="js/html2pdf.bundle.js"></script>
<script>
  function test() {
	// Get the element.
	var element = document.getElementById('tableid');

	// Choose pagebreak options based on mode.
	var mode = 'css';
	var pagebreak = (mode === 'specify') ?
		{ mode: '', before: '.before', after: '.after', avoid: '.avoid' } :
		{ mode: mode };

	// Generate the PDF.
	html2pdf().from(element).set({
		filename: 'report.pdf',
	  pagebreak: pagebreak,
	  jsPDF: {orientation: 'landscape', unit: 'in', format: 'letter', compressPDF: true}
	}).save();
  }
</script>