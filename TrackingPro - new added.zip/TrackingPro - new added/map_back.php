<?php include 'lib/header.php'; ?>
<link rel = "stylesheet" href = "css/mystyle.css" />
<div class = "container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div id = "tblposition">
				<table class="table">
					<thead class="table-title" data-toggle="collapse" href="#vehiclelist">
						<tr>
							<th scope="col">Icon</th>
							<th scope="col">Vehicle</th>
							<th scope="col">Status</th>
							<th scope="col"></th>
						</tr>
					</thead>
					<tbody class="collapse in" id="vehiclelist">
						<?php 
							$color = ['#f00', '#0F0', '#00F'];
							$i = 0;
							if($_GET['is_history'] == 0){
								
								$curl = curl_init();
								curl_setopt_array($curl, array(
								CURLOPT_URL => "https://login.trakingpro.com/api/get_devices_latest?lang=en&user_api_hash=$2y$10$2MW6Gu6l3azu4hAtLam.IO0098klDrojYzXaZ7f7eojkFrY4ZPMWq&time=1461956486",
								CURLOPT_RETURNTRANSFER => true,
								CURLOPT_ENCODING => "",
								CURLOPT_MAXREDIRS => 10,
								CURLOPT_TIMEOUT => 0,
								CURLOPT_FOLLOWLOCATION => true,
								CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
								CURLOPT_CUSTOMREQUEST => "GET",
								CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencod"),));
								$response = curl_exec($curl);
								curl_close($curl);
								$data = json_decode($response,true);
								
								$foreacharr = $data['items'];
							}else{
								$curl = curl_init();
								curl_setopt_array($curl, array(
								CURLOPT_URL => "https://login.trakingpro.com/api/get_history?lang=en&from_date=".$_POST['from_date']."&from_time=".$_POST['from_time']."&to_date=".$_POST['to_date']."&to_time=".$_POST['to_time']."&user_api_hash=$2y$10$2MW6Gu6l3azu4hAtLam.IO0098klDrojYzXaZ7f7eojkFrY4ZPMWq&time=1461956486&device_id=".$_GET['id'],
								CURLOPT_RETURNTRANSFER => true,
								CURLOPT_ENCODING => "",
								CURLOPT_MAXREDIRS => 10,
								CURLOPT_TIMEOUT => 0,
								CURLOPT_FOLLOWLOCATION => true,
								CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
								CURLOPT_CUSTOMREQUEST => "GET",
								CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencod"),));
								$response = curl_exec($curl);
								curl_close($curl);
								
								$curl = curl_init();
								curl_setopt_array($curl, array(
								CURLOPT_URL => "https://login.trakingpro.com/api/get_devices_latest?lang=en&user_api_hash=$2y$10$2MW6Gu6l3azu4hAtLam.IO0098klDrojYzXaZ7f7eojkFrY4ZPMWq&time=1461956486",
								CURLOPT_RETURNTRANSFER => true,
								CURLOPT_ENCODING => "",
								CURLOPT_MAXREDIRS => 10,
								CURLOPT_TIMEOUT => 0,
								CURLOPT_FOLLOWLOCATION => true,
								CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
								CURLOPT_CUSTOMREQUEST => "GET",
								CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencod"),));
								$response1 = curl_exec($curl);
								curl_close($curl);
								$data1=json_decode($response1,true);
								
								$history = []; $history_lat_long = [];
								$historylist=json_decode($response,true);
								if($historylist){
									foreach($historylist['items'] as $list){
										array_push($history_lat_long, array(
											"lat"=>$list['items'][0]['lat'],
											"lng"=>$list['items'][0]['lng']
										));
									}
								}else{
									echo "No Records Found";
								}
								$history = array(
									"items"=>array(
										"0"=>array(
											"id"=>$historylist['device']['id'],
											"name"=>$historylist['device']['name'],
											"online"=>'',
											"speed"=>'',
											"driver"=>'',
											"address"=>'',
											"tail"=>json_encode($history_lat_long)
										)
									)
								);
								$data = $history;
								$foreacharr = $data1['items'];
							}
							foreach($foreacharr as $vehicle){
								?>
									<tr>
										<th>
											<?php echo '<?xml version="1.0" encoding="iso-8859-1"?><svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 511.819 511.819" style="enable-background:new 0 0 511.819 511.819;" xml:space="preserve"> <path style="fill:'.$color[$i].';" d="M511.819,272.06v26.48c0,0-8.448,14.88-14.032,17.2h-101.28l-7.44-2.32l-3.264,7.44H133.051 l-0.672-0.24l-11.408-3.952L35.019,327.82c0,0-2.72-0.128-6.624-0.64c-10.944-1.424-31.152-5.856-26.368-18.88 c0,0-4.56-24.688,0-39.024c0,0,1.392-19.984,18.576-26.96c17.2-6.96,67.84-20.448,95.712-24.608c0,0,24.624-7.44,35.312-17.2 c0,0,24.112-18.016,53.888-31.072c16.048-7.024,33.216-11.168,50.656-12.8c33.744-3.168,107.088-8.048,153.776,3.44 c39.664,9.776,65.952,32.176,79.792,47.152c7.6,8.224,11.744,18.96,11.744,30.16v10.048l3.248,11.616 C504.747,259.052,511.819,264.156,511.819,272.06z"/> <path style="fill:#2E3235;" d="M132.587,315.9c0,1.584-0.064,3.168-0.208,4.72l-11.408-3.952L35.019,327.82 c0,0-2.72-0.128-6.624-0.64c-0.8-3.632-1.216-7.408-1.216-11.28c0-29.104,23.6-52.704,52.704-52.704S132.587,286.796,132.587,315.9z "/> <circle style="fill:#3E4347;" cx="79.883" cy="315.9" r="43.072"/> <path style="fill:#2E3235;" d="M388.059,315.708l1.008-2.304l7.44,2.32h96.944c-0.096-29.024-23.648-52.528-52.688-52.528 C411.707,263.196,388.155,286.7,388.059,315.708z"/> <g> <circle style="fill:#3E4347;" cx="440.747" cy="315.9" r="43.072"/> <path style="fill:#3E4347;" d="M287.499,166.652c-8.944,0.304-14.608,0.608-14.72,0.624l-0.32,0.016h-0.32 c-0.896-0.032-1.792-0.032-2.688-0.032c-39.056,0-77.968,23.2-97.696,37.024c-8.912,6.24-15.92,15.024-19.984,24.944l124.464-9.936 L287.499,166.652z"/> <path style="fill:#3E4347;" d="M403.771,174.444c-12.368-5.408-41.824-8.384-83.072-8.384c-4.832,0-9.52,0.048-13.936,0.112 l-4.48,51.024l0,0l123.344-9.84c0.4-2.304,0.736-4.496,0.976-6.496l0.016-0.16l0.032-0.16 C427.947,192.988,413.899,180.62,403.771,174.444z"/> </g> <g> <path style="fill:#FFD83B;" d="M11.019,261.468c0,0,17.136-19.952,36.336-18.448c4.672,0.368,18.64,6.624-3.2,18.448 c-6.832,3.696-20.272,5.872-30.496,6.032C5.371,267.612,11.019,261.468,11.019,261.468z"/> <path style="fill:#FFD83B;" d="M501.499,247.436v-10.048c0-4.336-0.8-8.544-2-12.624c-6.912-0.864-15.568-1.296-18.384,1.52 c-3.744,3.744-3.744,17.44,0,21.184c3.136,3.136,13.6,2.256,20.72,1.216L501.499,247.436z"/> </g> <circle style="fill:#CBD6E0;" cx="79.883" cy="315.9" r="28.752"/> <circle style="fill:#939799;" cx="79.883" cy="315.9" r="23.456"/> <g> <circle style="fill:#CBD6E0;" cx="79.883" cy="315.9" r="16.88"/> <circle style="fill:#CBD6E0;" cx="440.747" cy="315.9" r="28.752"/> </g> <circle style="fill:#939799;" cx="440.747" cy="315.9" r="23.456"/> <circle style="fill:#CBD6E0;" cx="440.747" cy="315.9" r="16.88"/> <g> <path style="fill:#5A5F63;" d="M180.875,226.892l26.192-2.096l32.944-53.568c-11.456,2.944-22.32,7.28-32.32,12.064 L180.875,226.892z"/> <path style="fill:#5A5F63;" d="M216.299,224.06l13.664-1.088l34.032-55.344c-4.688,0.256-9.344,0.768-13.968,1.584L216.299,224.06z "/> <path style="fill:#5A5F63;" d="M309.403,216.636l26.192-2.096l28.912-47.024c-7.296-0.544-15.392-0.944-24.192-1.168 L309.403,216.636z"/> <path style="fill:#5A5F63;" d="M344.811,213.804l13.664-1.088l26.416-42.96c-3.68-0.576-7.632-1.104-12.048-1.536L344.811,213.804z "/> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </svg>'; ?>
										</th>
										<td><?php echo $vehicle['name']; ?></td>
										<td><?php echo $vehicle['online']; ?></td>
										<td>
											<div class="dropdown">
											  <a class="dropdown-toggle" type="button" data-toggle="dropdown"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></a>
											  <ul class="dropdown-menu">
												<li><a href="#" data-toggle="modal" data-target="#history" >Show History</a></li>
												<li><a href="#" data-toggle="modal" data-target="#report" >Show Report</a></li>
											  </ul>
											</div>
										</td>
									</tr>
								<?php
								$i++;
							}
						?>
					</tbody>
				</table>
				<?php
					if($_GET['is_history'] == 1){
						?><div class = "bg-white"><?php
							$i = 0; $index = 0;
							foreach($foreacharr as $vehicle){
								if($vehicle['name'] == $data['items'][0]['name']){
									$index = $i;
								}
								$i++;
							}
							?>
							<h5 class = "text-center" data-toggle="collapse" href="#vehicledetails">Device Details</h5><hr/>
							<div class = "collalse in" id = "vehicledetails">
								<div class = "alert alert-info">History : <?php echo $_POST['from_date'].' '.$_POST['from_time'].' To<br/> '.$_POST['to_date'].' '.$_POST['to_time']; ?></div>
								<b>Device Id.</b> - <?php echo $data1['items'][$index]['id']; ?><br/>
								<b>Device Name.</b> - <?php echo $data1['items'][$index]['name']; ?><br/>
								<b>Online.</b> - <?php echo $data1['items'][$index]['online']; ?><br/>
								<b>Address</b> - <?php echo $data1['items'][$index]['address']; ?><br/>
								<b>Driver</b> - <?php echo $data1['items'][$index]['driver']; ?><br/>
								<b>Speed</b> - <?php echo $data1['items'][$index]['speed']; ?> km/hr<br/>
							</div>
							<?php
						?></div><?php
					}
				?>
			</div>
			<div id="map" style= "width:100%; height:100vh"></div>
		</div>
	</div>
</div>
<div id="history" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Check Device history</h4>
			</div>
			<div class="modal-body">
				<div class = "container-fluid">
					<form action = "history.php?id=<?php echo $_GET['id']; ?>&is_history=1" method = "post">
						<div class = "row form-group">
							<div class = "col-md-3">Device Id</div>
							<div class = "col-md-9">
								<select class = "form-control" name = "device_id">
									<option value = "">Select Device Id</option>
									<?php
										foreach($data['items'] as $vehicle){
											?><option value = "<?php echo $vehicle['id']; ?>"><?php echo $vehicle['name']; ?></option><?php
										}
									?>
								</select>
							</div>
						</div>
						<div class = "row form-group">
							<div class = "col-md-3">From</div>
							<div class = "col-md-5 col-xs-7 pr-0">
								<input type = "date" name = "from_date" class = "form-control" value = "<?php if($_POST['from_date']){ echo $_POST['from_date']; } ?>">
							</div>
							<div class = "col-md-4 col-xs-5 pl-0">
								<input type = "time" name = "from_time" class = "form-control" value = "<?php if($_POST['from_time']){ echo $_POST['from_time']; } ?>">
							</div>
						</div>
						<div class = "row form-group">
							<div class = "col-md-3">To</div>
							<div class = "col-md-5 col-xs-7 pr-0">
								<input type = "date" name = "to_date" class = "form-control" value = "<?php if($_POST['to_date']){ echo $_POST['to_date']; } ?>">
							</div>
							<div class = "col-md-4 col-xs-5 pl-0">
								<input type = "time" name = "to_time" class = "form-control" value = "<?php if($_POST['to_time']){ echo $_POST['to_time']; } ?>">
							</div>
						</div>
						<div class = "row form-group">
							<div class = "col-md-12 text-center"><hr/>
								<button class = "btn btn-warning">Show History</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<div id="report" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Check Device Report</h4>
			</div>
			<div class="modal-body">
				<div class = "container-fluid">
					<form action = "report.php" method = "post">
						<div class = "row form-group">
							<div class = "col-md-3">Device Id</div>
							<div class = "col-md-9">
								<select class = "form-control" name = "device_id">
									<option value = "">Select Device Id</option>
									<?php
										foreach($data['items'] as $vehicle){
											?><option value = "<?php echo $vehicle['id']; ?>"><?php echo $vehicle['name']; ?></option><?php
										}
									?>
								</select>
							</div>
						</div>
						<div class = "row form-group">
							<div class = "col-md-3">From</div>
							<div class = "col-md-5 col-xs-7 pr-0">
								<input type = "date" name = "from_date" class = "form-control" value = "<?php if($_POST['from_date']){ echo $_POST['from_date']; } ?>" value = "<?php if($_POST['from_date']){ echo $_POST['from_date']; } ?>">
							</div>
							<div class = "col-md-4 col-xs-5 pl-0">
								<input type = "time" name = "from_time" class = "form-control" value = "<?php if($_POST['from_time']){ echo $_POST['from_time']; } ?>">
							</div>
						</div>
						<div class = "row form-group">
							<div class = "col-md-3">To</div>
							<div class = "col-md-5 col-xs-7 pr-0">
								<input type = "date" name = "to_date" class = "form-control" value = "<?php if($_POST['to_date']){ echo $_POST['to_date']; } ?>">
							</div>
							<div class = "col-md-4 col-xs-5 pl-0">
								<input type = "time" name = "to_time" class = "form-control" value = "<?php if($_POST['to_time']){ echo $_POST['to_time']; } ?>">
							</div>
						</div>
						<div class = "row form-group">
							<div class = "col-md-12 text-center"><hr/>
								<button class = "btn btn-warning">Show Report</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script>window.jQuery || document.write('<script src="js/jquery-slim.min.js"><\/script>')</script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
 <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
<script src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyB5NXz9eVnyJOA81wimI8WYE08kW_JMe8g&libraries=geometry"></script>
<!----Firebase notifications------>
<script src="https://www.gstatic.com/firebasejs/8.2.4/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.3/firebase-messaging.js"></script>

<script type="text/javascript">
	
	//varible declaration
	var latlongarr = []; devices = []; symbolarr = []; startPos = []; color = ['#f00', '#0F0', '#00F'], contentarr = [];
	var map, infoWindow, bounds = null;
	var speed = 100; // km/h
	var bearing = 100;

	//get api data result
	<?php
		//device id
		foreach($data['items'] as $arrname){
			$content = '';
			?>
				devices.push("<?php echo $arrname['name']; ?>");  
				var latlongsubarr = [];
			<?php
			
			$tail_arr = json_decode($arrname['tail'], true);
			$lat_lng_sub = [];
			$initial_lat = ''; $initial_lng = ''; $initial_count = 0;
			foreach($tail_arr as $tail){
				$initial_count++;
				if($initial_count == 1){
					$initial_lat = $tail['lat']; 
					$initial_lng = $tail['lng'];
				}
				?> 
					var latlongsubarr1 = []; 
					latlongsubarr1.push(<?php echo (string)$tail['lat']; ?>, <?php echo (string)$tail['lng']; ?>); 
					latlongsubarr.push(latlongsubarr1);
				<?php
			}
			$content .= "<small><b>Name :</b> ".$arrname['name']."<br/><b>Speed : </b>".$arrname['speed']."<br/><b>Online : </b>".$arrname['online']."<br/><b>Driver : </b>".$arrname['driver']."<br/><b>Address : </b>".$arrname['address']."</small>"
			?>
				contentarr.push("<?php echo $content; ?>");
				latlongarr.push(latlongsubarr); 
			<?php	
		}
	?>
	
	//define object properties
	for(var i = 0; i<latlongarr.length; i++){
		if(latlongarr[i].length != 0){
			startPos.push(latlongarr[i][0]);
			symbolarr[i] = {  
				path: "M62.1,36.5c-0.9-1.2-3.6-1.5-3.6-1.5c0.1-3.5,0.5-6.9,0.7-8.2c1.9-7.3-1.7-11.8-1.7-11.8c-4.8-4.8-9.1-5-12.5-5   c-3.4,0-7.8,0.3-12.5,5c0,0-3.6,4.5-1.7,11.8c0.2,1.2,0.5,4.6,0.7,8.2c0,0-2.7,0.3-3.6,1.5c-0.9,1.2-0.9,1.9,0,1.9   c0.9,0,2.9-2.3,3.6-2.3V35c0,1,0.1,2,0.1,3c0,4.4,0,33.7,0,33.7s-0.3,6.1,5,7.8c1.2,0,4.6,0.4,8.4,0.5c3.8-0.1,7.3-0.5,8.4-0.5   c5.3-1.7,5-7.8,5-7.8s0-29.3,0-33.7c0-1,0-2,0.1-3v1.2c0.7,0,2.7,2.3,3.6,2.3C63,38.5,63,37.7,62.1,36.5z M34.7,66.5   c-0.3,3.3-2.3,4.1-2.3,4.1V37.4c0.8,1.2,2.3,6.8,2.3,6.8S34.9,63.2,34.7,66.5z M54.8,75.2c0,0-4.2,2.3-9.8,2.2   c-5.6,0.1-9.8-2.2-9.8-2.2v-2.8c4.9,2.2,9.8,2.2,9.8,2.2s4.9,0,9.8-2.2V75.2z M35.2,41.1l-1.7-10.2c0,0,4.5-3.2,11.5-3.2   s11.5,3.2,11.5,3.2l-1.7,10.2C51.4,39.2,38.6,39.2,35.2,41.1z M57.7,70.6c0,0-2.1-0.8-2.3-4.1c-0.3-3.3,0-22.4,0-22.4   s1.5-5.6,2.3-6.8V70.6z",
				fillColor: color[i],
				fillOpacity: .5,
				anchor: new google.maps.Point(35, 35),
				strokeWeight: 1,
				scale: .5,
				rotation: bearing  
			}
		}
	}

	//object animation functionality
	var delay = 100;
	function animateMarker(marker, coords, km_h, symbol, i_position){
		
		
		var target = 0;
		var km_h = km_h || 50;
		coords.push([startPos[i_position][0], startPos[i_position][1]]);
		
		function goToPoint(){
			if (target < coords.length){
				var lastPosn = marker.getPosition();
				var lat = marker.position.lat();
				var lng = marker.position.lng();
				var step = (km_h * 1000 * delay) / 3600000; // in meters

				var start = new google.maps.LatLng(startPos[i_position][0], startPos[i_position][1]);
				var dest = new google.maps.LatLng(coords[target][0], coords[target][1]);
				
				

				var distance = google.maps.geometry.spherical.computeDistanceBetween(dest, marker.position);
				var numStep = distance / step;
				var i = 0;
				var deltaLat = (coords[target][0] - lat) / numStep;
				var deltaLng = (coords[target][1] - lng) / numStep;

				function moveMarker(){
					
					
					lat += deltaLat;
					lng += deltaLng;
					
					
				
					i += step;
				   if(i < distance){
						var p = new google.maps.LatLng(lat, lng);
						
						marker.setPosition(p);
						var heading = google.maps.geometry.spherical.computeHeading(lastPosn, p);
						symbol.rotation = heading;
						marker.setIcon(symbol);
						setTimeout(moveMarker, delay);
				   }else{   
						marker.setPosition(dest);
						
						var heading = google.maps.geometry.spherical.computeHeading(lastPosn, dest);
						symbol.rotation = heading;
						marker.setIcon(symbol);
						target++;
						//if (target == coords.length){ target = 0; }
						setTimeout(goToPoint, delay);
					}
				}
				
				moveMarker();
			}
		}
		goToPoint();
	}

	function initialize(){
		var responsiveZoom = <?php if($_GET['is_history'] == 0){ ?> (window.innerWidth < 768) ? 6.75 : 5.75; <?php }else{ ?> (window.innerWidth < 768) ? 20 : 19; <?php } ?>
		
		
		<?php if($_GET['is_history'] == 0){ ?>
			//set focus on map at the center of india
			var myLatlng =  new google.maps.LatLng(20.5937, 78.9629);
		<?php }else if($initial_lat != '' && $initial_lng){
			?>
			var myLatlng =  new google.maps.LatLng(<?php echo $initial_lat; ?>, <?php echo $initial_lng; ?>);
			<?php
		}else{ ?>
			alert('No history for these dates');
			window.location.href = "dashboard.php";
			var myLatlng =  new google.maps.LatLng(20.5937, 78.9629);
		 <?php } ?>
		
		//map properties
		var myOptions={styles: [{"elementType": "geometry", "stylers": [{"color": "#f5f5f5"}]},{"elementType": "labels.icon", "stylers": [{"color": "#f5f5f5"}]},{"elementType": "labels.text.fill", "stylers": [{"color": "#616161"}]},{"elementType": "labels.text.stroke", "stylers": [{"color": "#f5f5f5"}]},{"featureType": "administrative.country", "elementType": "geometry.stroke", "stylers": [{"color": "#00338D"},{"visibility": "on"},{"weight": 2}]},{"featureType": "administrative.land_parcel", "elementType": "labels.text.fill", "stylers": [{"color": "#bdbdbd"}]},{"featureType": "poi", "elementType": "labels", "stylers": [{"visibility": "off"}]},{"featureType": "road", "elementType": "geometry", "stylers": [{"color": "#ffffff"}]},{"featureType": "road.arterial", "elementType": "labels.text.fill", "stylers": [{"color": "#757575"}]},{"featureType": "road.highway", "elementType": "geometry", "stylers": [{"color": "#dadada"}]},{"featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [{"color": "#616161"}]},{"featureType": "road.local", "elementType": "labels.text.fill", "stylers": [{"color": "#9e9e9e"}]},{"featureType": "water", "elementType": "geometry.fill", "stylers": [{"color": "#bbdefb"}]},{"featureType": "water", "elementType": "labels.text.fill", "stylers": [{"color": "#9e9e9e"}]}], zoom: responsiveZoom, minZoom: responsiveZoom-22, maxZoom: responsiveZoom+22, zoomControl: true, zoomControlOptions:{style: google.maps.ZoomControlStyle.DEFAULT}, center: myLatlng, mapTypeId: google.maps.MapTypeId.TERRAIN, scrollwheel: false, panControl: false, mapTypeControl: false, scaleControl: false, streetViewControl: true, overviewMapControl: false, rotateControl: true};
		map = new google.maps.Map(document.getElementById("map"), myOptions);
		
		var bounds  = new google.maps.LatLngBounds()
		map.panToBounds(bounds);
		
		//define marker in loop
		markerarr = [];
		for(var i = 0; i<latlongarr.length; i++){
			if(latlongarr[i].length != 0){
				markerarr[i] = new google.maps.Marker({
					position: new google.maps.LatLng(startPos[0], startPos[1]),
					map: map,
					icon: symbolarr[i],
					title: devices[i],
				});
				
				//show window info
				infoWindow = new google.maps.InfoWindow({
				  content: contentarr[i],
				  position: markerarr[i].getPosition(),
				});
				infoWindow.open( map, markerarr[i] );
				//extend bound of map
				bounds.extend(markerarr[i].getPosition());
				google.maps.event.addListener(markerarr[i], "click", function() {
					map.setZoom(18);
				})
			}
		}
						
		//set object idle
		google.maps.event.addListenerOnce(map, 'idle', function(){
			for(var i = 0; i<latlongarr.length; i++){
				if(latlongarr[i].length != 0){
					animateMarker(markerarr[i], latlongarr[i], speed, symbolarr[i], i);
				}
			}
		});
		
		
		circle = new google.maps.Circle( {
			map           : map,
			center        : new google.maps.LatLng( 20.5937, 78.9629 ),
			radius        : 200000000,
			strokeColor   : '#FF0',
			strokeOpacity : 1,
			strokeWeight  : 2,
			fillColor     : '#009ee0',
			fillOpacity   : 0.2
		} )
		
	}
	initialize();
	
	
	
	// Initialize Firebase
	var config = {
	apiKey: "AIzaSyB4aXX6OKTDj9t581oe5xHApREsr4vrSHg",
		authDomain: "shahmarketing-c54f0.firebaseapp.com",
		projectId: "shahmarketing-c54f0",
		storageBucket: "shahmarketing-c54f0.appspot.com",
		messagingSenderId: "1058331201045",
		appId: "1:1058331201045:web:d3dcacba22238f212a081c",
		measurementId: "G-JBERDYZ0LV"
	};
	firebase.initializeApp(config);

	// Retrieve Firebase Messaging object.
	const messaging = firebase.messaging();
	messaging.requestPermission().then(function() {
		if(isTokenSentToServer()) {
			getRegToken();
		}
	}).catch(function(err) {
		console.log('Unable to get permission to notify.', err);
	});

	function getRegToken(argument) {
		messaging.getToken().then(function(currentToken) {
			if (currentToken) {
				saveToken(currentToken);
				console.log(currentToken);
				setTokenSentToServer(true);
			}else {
				console.log('No Instance ID token available. Request permission to generate one.');
				setTokenSentToServer(false);
			}
		}).catch(function(err) {
			console.log('An error occurred while retrieving token. ', err);
			setTokenSentToServer(false);
		});
	}
	function setTokenSentToServer(sent){
		window.localStorage.setItem('sentToServer', sent ? 1 : 0);
	}
	function isTokenSentToServer(){
		return window.localStorage.getItem('sentToServer') == 1;
	}
	function saveToken(currentToken) {
		$.post('setfirebasetoken.php', {'token':currentToken}, function(data){
			console.log('success')
		})
	}
	messaging.onMessage(function(payload) {
		console.log("Message received. ", payload);
		notificationTitle = payload.data.title;
		notificationOptions = {
			body: payload.data.body,
			icon: payload.data.icon,
			image: payload.data.image
		};
		var notification = new Notification(notificationTitle,notificationOptions);
	});
	
	
	//sidebar
	if(window.innerWidth < 768){
		$('.main-nav').hide();
	}
	$('.navbar-toggler').click(function(){
		if($(this).hasClass('collapsed')){
			$('.main-nav').hide();
		}else{
			$('.main-nav').show();
		}
	})
	google.maps.event.addDomListener(window, 'load', initialize);
</script>