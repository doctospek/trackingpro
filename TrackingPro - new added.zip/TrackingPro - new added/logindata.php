<?php
	session_start();
	include_once('config.php');
	$sql = "SELECT * FROM `admin` WHERE `username`='".$_POST['email']."' AND `password` = '".base64_encode($_POST['pass'])."'";
	$res = mysqli_query($conn, $sql);
	if(mysqli_num_rows($res) > 0){
		//get access from access setting if not get role access setting details
		$id = mysqli_fetch_array($res);
		
		//set session
		$_SESSION['username'] = $id['username'];
		$_SESSION['name'] = $id['name'];
		$_SESSION['email'] = $id['email'];
		$_SESSION['login_user'] = '$2y$10$2MW6Gu6l3azu4hAtLam.IO0098klDrojYzXaZ7f7eojkFrY4ZPMWq'; //$id['id'];
		
		header('location:dashboard.php');
	}else{
		header('location:index.php');
	}
?>