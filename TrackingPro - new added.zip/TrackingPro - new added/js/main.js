$(document).ready(function(){
    $("#profile").click(function(){
        $("#profile-menu").toggle();
    });

    $("#mob-menu").click(function(){
        $("#tr-menu").toggle();
        
    });

  });

  function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
  }

  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }