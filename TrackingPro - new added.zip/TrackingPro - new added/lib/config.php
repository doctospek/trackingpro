<?php
//session_start();
ini_set("display_errors",0);

/**********************General WebSite Settings************************************/
date_default_timezone_set('Asia/Calcutta');
define('DATE_FORMAT', 'd-M-Y');
define('DATE_TIME_FORMAT', 'd-M-Y, h:i a');
$current_date = date("M,d,Y h:i:s A");
// Site URL
$site_url = "https://trakingpro.com"; // e.g (http://example.com)
$info='info@trakingpro.com';
$Project_name='Trakingpro';
/*****************Socal Media Link*******************/
$facebook_link='https://www.facebook.com/TrakingPro/';
$twitter_link='https://twitter.com/trakingpro';
$linkedin_link='https://www.linkedin.com/company/13470129/';
$whatsapp_link='https://api.whatsapp.com/send?phone=9073635020';
$contact_number1='+9073635020';
$contact_number2='+033 30992093';
/*****************Socal Media Link*******************/
/**********************Verson Cheange***************/
$verson='V2.4';
/**********************Verson Cheange***************/
/**********************Sms API Settings************************************/
$username = 'Traking'; //use your sms api username
$pass = '123456';//enter your password
$senderid = 'TRAPRO';//BTOYOU use your sms api sender id
/**********************Database config************************************/
if ($_SERVER['HTTP_HOST']=='localhost' )
{
$dbHost     =  'localhost';
$dbName     =  'crm_portal_test';
$dbUsername =  'root';
$dbPassword =  '';
}
else 
{
$dbHost     =  'localhost';
$dbName     =  'trakingp_portal';
$dbUsername =  'trakingp_portal';
$dbPassword =  '^ocA2$*lJ#@Q';
}
/**********************mysqli_connect***************************/
$con = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName)
or die('Oops connection error -> ' . mysqli_connect_error());
/**********************End************************************/
?>