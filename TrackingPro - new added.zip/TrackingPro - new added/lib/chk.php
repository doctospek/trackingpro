<?php 
session_start();

include "config.php";  
include "function.php";  

if(isset($_POST['submit'])){ 

$id=mysqli_real_escape_string($con,$_POST['name']);
$pass=mysqli_real_escape_string($con,$_POST['password']);
$type=mysqli_real_escape_string($con,$_POST['type']);

$sql=mysqli_query($con,"SELECT * FROM `createagent` WHERE `UMobileNo`='".$id."' and `Password`='".$pass."' and `status`='1' ");
$row=mysqli_num_rows($sql);
$result=mysqli_fetch_assoc($sql);

if($row==1){ 
$_SESSION['id']=$result['id'];
$_SESSION['who']=$result['type'];

if ($result['type']=="admin") {
redirect('../dashboard.php?done'); 
}

if ($result['type']=="SUPER DISTRIBUTOR") {
redirect('../super-dashboard.php?done'); 
}

if ($result['type']=="DISTRIBUTOR") {
redirect('../distributor-dashboard.php?done'); 
}

if ($result['type']=="RETAILER") {
redirect('../retailer-dashboard.php?done'); 
}

if ($result['type']=="SUPER DISTRIBUTOR1") {
redirect('../aeps-retailer-dashboard.php?done'); 
}


} else {   redirect('../index.php?error');   } } ?>