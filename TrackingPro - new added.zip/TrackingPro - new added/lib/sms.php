<?php
$number=$dest_mobileno;

$sms = urlencode($message);
$priority = "ndnd";//BTOYOU use your sms api sender id
$stype = "normal";//BTOYOU use your sms api sender id 

$var="user=".$username."&pass=".$pass."&sender=".$senderid."&phone=".$number."&text=".$sms."&priority=".$priority."&stype=".$stype."";

$curl=curl_init('http://bhashsms.com/api/sendmsg.php?'.$var);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
$response=curl_exec($curl);
curl_close($curl);
//echo $response; 
?>