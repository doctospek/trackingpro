<?php
//include "function.php";
//session_start();

// if (!empty($_SESSION['user_id'])) {
// 	$query = mysqli_query($sqlConnect, "DELETE FROM " .  T_APP_SESSIONS . " WHERE `session_id` = '" . Wo_Secure($_SESSION['user_id']) . "'");
// }
session_destroy();
header("location: ../index.php");
//redirect('./index.php'); 
//exit();