<?php
function header_redirect($location)
{
	echo "<script>location.href='".$location."'</script>";
	exit();
}


function randomPassword() {
$alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
$pass = array(); //remember to declare $pass as an array
$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
for ($i = 0; $i < 8; $i++) {
$n = rand(0, $alphaLength);
$pass[] = $alphabet[$n];
}
return implode($pass); //turn the array into a string
}

// Getting session 
function get_session()
{
return $_SESSION['login'];
}

//Check sqlinjection
function checkSqlInjection($string='',$mysql_real_escape=true){		
if($mysql_real_escape){
$string=mysqli_real_escape_string($con,$string);
}
return $string;
}	

//CHECKING EXISTANCE  IN A TABLE
function existsInTable($tblName, $condition)
{
if(trim($condition) != "")
{
$condition = " WHERE " . $condition;
}
else
{
$condition = "";
}
//echo ("select * from " . $tblName . " where " . $condition)."<br>";
$rs = mysqli_query($con,"select * from " . $tblName . $condition);
if( (!($rs)) || (!($rec=mysqli_fetch_array($rs))) )
{
//not found
return 0;
}
else
{
//found
return 1;
}
}
// ********************************END*********************************************************

function fetchSingle($tblName,$field='*',$optCondition=""){
if(trim($optCondition)!= ""){
$sql = "SELECT ".$field." from ".$tblName." WHERE " . $optCondition;
}else{
$sql = "SELECT ".$field." from ".$tblName;
}			
//echo $sql."<br>";
$result = mysqli_query($con,$sql);
return mysqli_fetch_assoc($result);
}

function getDataFromTable($tblName, $fldName,$optCondition){
$defaultVal="";		
if(trim($optCondition) != ""){
$condition = $optCondition ;
}else{
$condition = "";
}	
//echo "select " . $fldName . " from " . $tblName . " where " . $condition."<br>";	
$rs = mysqli_query($con,"select " . $fldName . " from " . $tblName . " where " . $condition);
if( (!($rs)) || (!($rec=mysqli_fetch_array($rs))) ){						
return $defaultVal;
}else if(is_null($rec[0])){			
return $defaultVal;
}else{		
return $rec[0];
}
}

########################## INSERTSET ##################################
function insertSet($tblName,$string){		
//echo "INSERT INTO " . $tblName . " SET " . $string;exit;
$rs= mysqli_query($con,"INSERT INTO  " . $tblName . " SET " .  $string);
if($rs){
$lastId=mysqli_insert_id($this->dbcon);
return $lastId;
}else{
return 0;
}
}

########################## UPDATETABLE#################################
function updateTable($tblName,$string, $condition){
$condition = " WHERE " . $condition;
$sql="UPDATE " . $tblName . " SET " .  $string . $condition;
$sql."<br>";//exit;
$rs= mysqli_query($con,$sql);
//echo "UPDATE " . $tblName . " SET " .  $string . $condition."<br>";	exit;
}

########################## DELETEFROMTABLE ############################
 function deleteFromTable($tblName, $condition){	
if(trim($condition) != ""){
$condition = " WHERE " . $condition;
}else{
$condition = "";
}
//echo "DELETE FROM " . $tblName . $condition;exit;
return $rs= mysqli_query($con,"DELETE FROM " . $tblName . $condition);
}

// function countRows($tblName,$optCondition="",$groupby="") {
// if(trim($optCondition) != ""){
// $condition = " WHERE " . $optCondition;
// }else{
// $condition = "";
// }

// if($groupby!=""){
// $sql="SELECT * FROM " . $tblName . $condition." group by ".$groupby;
// }else{
// $sql="SELECT * FROM " . $tblName . $condition;
// }
// //echo $sql."<br/>";//exit;
// $result = mysqli_query($con,$sql);		
// return $result=mysqli_num_rows($result);
// }





#####################FETCHING ROWS############################
	###############################################################	
	function fetchOrder($tblName,$optCondition="",$orderby="",$field="",$groupby=""){
		if($field==""){
			$sql = "SELECT * FROM ".$tblName;
		}else{
			$sql = "SELECT ".$field." FROM ".$tblName;
		}		
		if(trim($optCondition) != ""){
			$sql = $sql." WHERE " . $optCondition;
		}
		if($groupby != ""){
			$sql = $sql." group by " . $groupby;
		}
		if(trim($orderby) != "" ){
			$sql = $sql." order by " . $orderby;
		}		
		//echo $sql;
		$result = mysqli_query($con,$sql);
		if(!$result){
			trigger_error("Problem selecting data");
		}
		while($row = mysqli_fetch_assoc($result)){
			$result_array[] = $row;
		}
		if(count($result_array)>0){
			return $result_array;	
		}else{
			$default_val=array();
			return $default_val;
		}
	}

// function fetchOrder($tblName,$optCondition=""){
		 
// 			$sql = "SELECT * FROM ".$tblName;
		 
// 		$result = mysqli_query($con,$sql);
		 
// 		while($row = mysqli_fetch_assoc($result)){
// 			$result_array[] = $row;
// 		}
		 
// 	}

	# With Limit
	function fetchDatatfrommultipleTable($tblName,$optCondition="",$orderby="",$field="",$optlimit="",$optorderType="ASC"){
		if($field==""){
			$sql = "SELECT * FROM ".$tblName;
		}else{
			$sql = "SELECT ".$field." FROM ".$tblName;
		}		
		if(trim($optCondition) != ""){
			$sql = $sql." WHERE " . $optCondition;
		}
		
		if(trim($orderby) != "" ){
			$sql = $sql." order by " . $orderby;
		}		
		
		if(trim($optorderType)!=""){
			$sql=$sql." ".$optorderType;
		}
		if(trim($optlimit) != ""){
			$sql = $sql.$optlimit;
		}
//		echo $sql;exit;
		$result = mysqli_query($con,$sql);
		if(!$result){
			trigger_error("Problem selecting data");
		}
		while($row = mysqli_fetch_assoc($result)){
			$result_array[] = $row;
		}
		if(count($result_array)>0){
			return $result_array;	
		}else{
			$default_val=array();
			return $default_val;
		}
	}  

?>