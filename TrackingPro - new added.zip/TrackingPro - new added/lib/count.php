<?php
$sql_DISTRIBUTOR=mysqli_query($con,"SELECT * FROM `createagent` WHERE `type`='DISTRIBUTOR' AND  `refer_id`='$_SESSION[id]' ");
$Distributor_as_super=mysqli_num_rows($sql_DISTRIBUTOR);