<?php  session_start(); ?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<title>Dashboard</title>
<script src="https://kit.fontawesome.com/73329a7e80.js" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>   

<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/mystyle.css" rel="stylesheet">
<script src="js/clock.js"></script>
<script src="js/main.js"></script>
</head>

<body class="bg-grey">
<nav class="navbar navbar-expand-md navbar-dark track-nav bg-primary fixed-top">
<div class="track-logo"><a href  = "dashboard.php"><img src="img/logo.png" width="90%" alt=""></a></div>
<div class="mobile-menu" id="mob-menu"><i class="fas fa-bars"></i></div>
<div class="profile-img fl-right" id="profile"></div>
<div id="profile-menu">
<ul class="profile-menu">
<li><a href="#">Profile</a></li>
<li><a href="lib/logout.php">Logout</a></li>
</ul>
</div>
</nav>

<div class="row main-nav">
<div class="col-md-2">
</div>

<div class="col-md-8" id="tr-menu">
<ul>
<li class="nav-menu"><a href="dashboard.php"><i class="fas fa-home" ></i> Dashboard</a></li>
<li class="nav-menu"><a href="map.php"><i class="fas fa-car-alt" ></i> Vehicle</a></li>
<li class="nav-menu"><a href=""><i class="fas fa-bullseye" ></i> Geofencing</a></li>
<li class="nav-menu"><a href=""><i class="fas fa-file-pdf" ></i> Reports</a></li>

<!--<li class="nav-menu"><a href=""><i class="fas fa-location-arrow" ></i> Tracking</a></li>-->
<!--<li class="nav-menu"><a href=""><i class="fas fa-map-pin" ></i> poi list</a></li>-->
<!--<li class="nav-menu"><a href=""><i class="fas fa-compass" ></i> routes</a></li>-->
<!--<li class="nav-menu"><a href=""><i class="fas fa-layer-group" ></i> Groups</a></li>-->
<!--<li class="nav-menu"><a href=""><i class="fas fa-user-circle" ></i> Admin</a></li>  -->
<!--<li class="nav-menu"><a href=""><i class="fas fa-broadcast-tower" ></i> sensor</a></li>-->
</ul>
</div>
<div class="main-clock col-md-2">
<i class="fas fa-clock" ></i> Time Now: <span id="time">00:00:00 PM</span>
</div>
</div>